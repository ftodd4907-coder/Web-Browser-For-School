/* Injected into every proxied page. Keeps dynamic requests flowing through the proxy
   and reports navigation/title changes to the parent browser UI. */
(function () {
  if (window.__PROXY_SHIM__) return;
  window.__PROXY_SHIM__ = true;

  var BASE = window.__PROXY_BASE__ || location.href;
  var PROXY_ORIGIN = location.origin;
  var PREFIX = PROXY_ORIGIN + '/proxy?url=';

  function isProxied(u) {
    return typeof u === 'string' && u.indexOf('/proxy?url=') !== -1;
  }
  function skip(u) {
    return /^(data:|blob:|javascript:|mailto:|tel:|about:|#)/i.test(u);
  }
  function abs(u) {
    try { return new URL(u, BASE).href; } catch (e) { return u; }
  }
  function wrap(u) {
    if (typeof u !== 'string') {
      try { u = String(u); } catch (e) { return u; }
    }
    var t = u.trim();
    if (!t || skip(t) || isProxied(t)) return u;
    // Links to our own origin produced by relative URL resolution should be
    // re-resolved against the real base instead.
    try {
      var parsed = new URL(t, BASE);
      if (parsed.origin === PROXY_ORIGIN && parsed.pathname.indexOf('/proxy') === 0) return u;
      if (parsed.origin === PROXY_ORIGIN && parsed.pathname.indexOf('/static/') === 0) return u;
      if (parsed.origin === PROXY_ORIGIN) {
        // Relative URL resolved against proxy origin -> resolve against real base
        parsed = new URL(parsed.pathname + parsed.search + parsed.hash, BASE);
      }
      return PREFIX + encodeURIComponent(parsed.href);
    } catch (e) {
      return u;
    }
  }
  function unwrap(u) {
    try {
      var p = new URL(u, PROXY_ORIGIN);
      if (p.pathname === '/proxy' && p.searchParams.get('url')) return p.searchParams.get('url');
    } catch (e) {}
    return u;
  }

  // ---- Tell the parent browser about this page ----
  function report() {
    try {
      parent.postMessage({ type: 'proxy:navigate', url: BASE, title: document.title || '' }, '*');
    } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', report);
  else report();
  window.addEventListener('load', report);
  // Title changes
  var titleObs = new MutationObserver(report);
  function watchTitle() {
    var t = document.querySelector('title');
    if (t) titleObs.observe(t, { childList: true, characterData: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watchTitle);
  else watchTitle();

  // ---- Fake location so scripts see the real URL ----
  var realLoc;
  try { realLoc = new URL(BASE); } catch (e) { realLoc = null; }

  // ---- fetch ----
  var _fetch = window.fetch;
  if (_fetch) {
    window.fetch = function (input, init) {
      try {
        if (typeof input === 'string') input = wrap(input);
        else if (input instanceof Request) {
          var w = wrap(input.url);
          if (w !== input.url) input = new Request(w, input);
        } else if (input instanceof URL) input = wrap(input.href);
      } catch (e) {}
      return _fetch.call(this, input, init);
    };
  }

  // ---- XMLHttpRequest ----
  var _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    try { arguments[1] = wrap(url); } catch (e) {}
    return _open.apply(this, arguments);
  };

  // ---- sendBeacon ----
  if (navigator.sendBeacon) {
    var _beacon = navigator.sendBeacon.bind(navigator);
    navigator.sendBeacon = function (url, data) {
      try { url = wrap(url); } catch (e) {}
      return _beacon(url, data);
    };
  }

  // ---- WebSocket / EventSource / Worker: can't proxy, let them fail quietly ----
  var _WS = window.WebSocket;
  if (_WS) {
    window.WebSocket = function (url, protocols) {
      try {
        var u = new URL(url, BASE);
        // No WebSocket proxying; keep a dummy to avoid crashes
        return protocols ? new _WS(u.href, protocols) : new _WS(u.href);
      } catch (e) {
        return protocols ? new _WS(url, protocols) : new _WS(url);
      }
    };
    window.WebSocket.prototype = _WS.prototype;
    window.WebSocket.CONNECTING = 0; window.WebSocket.OPEN = 1; window.WebSocket.CLOSING = 2; window.WebSocket.CLOSED = 3;
  }
  if (window.Worker) {
    var _Worker = window.Worker;
    window.Worker = function (url, opts) {
      try { url = wrap(url); } catch (e) {}
      return new _Worker(url, opts);
    };
    window.Worker.prototype = _Worker.prototype;
  }
  if (navigator.serviceWorker) {
    try { navigator.serviceWorker.register = function () { return Promise.reject(new Error('Service workers disabled in proxy')); }; } catch (e) {}
  }

  // ---- Dynamic DOM: patch URL attribute setters ----
  function patchAttr(proto, prop) {
    var d = Object.getOwnPropertyDescriptor(proto, prop);
    if (!d || !d.set) return;
    Object.defineProperty(proto, prop, {
      get: d.get,
      set: function (v) { d.set.call(this, prop === 'srcset' ? wrapSrcset(v) : wrap(v)); },
      configurable: true,
      enumerable: d.enumerable
    });
  }
  function wrapSrcset(v) {
    if (typeof v !== 'string') return v;
    return v.split(',').map(function (p) {
      var parts = p.trim().split(/\s+/);
      if (!parts[0]) return p;
      parts[0] = wrap(parts[0]);
      return parts.join(' ');
    }).join(', ');
  }
  patchAttr(HTMLImageElement.prototype, 'src');
  patchAttr(HTMLImageElement.prototype, 'srcset');
  patchAttr(HTMLScriptElement.prototype, 'src');
  patchAttr(HTMLLinkElement.prototype, 'href');
  patchAttr(HTMLIFrameElement.prototype, 'src');
  patchAttr(HTMLSourceElement.prototype, 'src');
  patchAttr(HTMLSourceElement.prototype, 'srcset');
  patchAttr(HTMLMediaElement.prototype, 'src');
  patchAttr(HTMLVideoElement.prototype, 'poster');
  patchAttr(HTMLEmbedElement.prototype, 'src');
  patchAttr(HTMLTrackElement.prototype, 'src');
  patchAttr(HTMLFormElement.prototype, 'action');
  patchAttr(HTMLAnchorElement.prototype, 'href');
  patchAttr(HTMLAreaElement.prototype, 'href');

  var URL_ATTRS = { src: 1, href: 1, action: 1, poster: 1, data: 1, formaction: 1, srcset: 2 };
  var _setAttribute = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, value) {
    try {
      var n = String(name).toLowerCase();
      if (URL_ATTRS[n] && typeof value === 'string') {
        // Don't rewrite href on <a> for fragments etc; wrap() already skips those
        if (n === 'srcset') value = wrapSrcset(value);
        else if (!(n === 'href' && this.tagName === 'USE')) value = wrap(value);
      }
    } catch (e) {}
    return _setAttribute.call(this, name, value);
  };

  // Rewrite anything inserted via innerHTML etc. using a MutationObserver
  var SELECTOR = '[src],[href],[action],[poster],[srcset],[data]';
  function fixEl(el) {
    if (!el || el.nodeType !== 1) return;
    var attrs = ['src', 'href', 'action', 'poster', 'data', 'formaction'];
    for (var i = 0; i < attrs.length; i++) {
      var a = attrs[i];
      if (!el.hasAttribute(a)) continue;
      if (a === 'href' && (el.tagName === 'USE' || el.tagName === 'use')) continue;
      var v = el.getAttribute(a);
      var w = wrap(v);
      if (w !== v) _setAttribute.call(el, a, w);
    }
    if (el.hasAttribute('srcset')) {
      var sv = el.getAttribute('srcset'); var sw = wrapSrcset(sv);
      if (sw !== sv) _setAttribute.call(el, 'srcset', sw);
    }
    if (el.hasAttribute('integrity')) el.removeAttribute('integrity');
    if (el.hasAttribute('target') && el.getAttribute('target') !== '_self') _setAttribute.call(el, 'target', '_self');
    if (el.tagName === 'STYLE' && el.textContent && /url\(/i.test(el.textContent)) {
      el.textContent = rewriteCss(el.textContent);
    }
    var st = el.getAttribute && el.getAttribute('style');
    if (st && /url\(/i.test(st)) _setAttribute.call(el, 'style', rewriteCss(st));
  }
  function rewriteCss(css) {
    return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, function (m, q, u) {
      return 'url(' + q + wrap(u) + q + ')';
    });
  }
  var domObs = new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i];
      if (m.type === 'childList') {
        for (var j = 0; j < m.addedNodes.length; j++) {
          var n = m.addedNodes[j];
          if (n.nodeType !== 1) continue;
          fixEl(n);
          if (n.querySelectorAll) {
            var all = n.querySelectorAll(SELECTOR + ',style,[style]');
            for (var k = 0; k < all.length; k++) fixEl(all[k]);
          }
        }
      }
    }
  });
  function startObs() {
    domObs.observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.documentElement) startObs(); else document.addEventListener('DOMContentLoaded', startObs);

  // ---- Navigation: window.open, location assignments ----
  var _openWin = window.open;
  window.open = function (url, name, feats) {
    try {
      if (url) {
        // Open in the same tab (parent browser can handle it)
        parent.postMessage({ type: 'proxy:open', url: abs(String(url)) }, '*');
        return null;
      }
    } catch (e) {}
    return _openWin.apply(window, arguments);
  };

  // history.pushState / replaceState: keep URLs proxied & inform parent
  function patchHistory(name) {
    var orig = history[name];
    history[name] = function (state, title, url) {
      try {
        if (url != null) {
          var realAbs = new URL(String(url), BASE).href;
          BASE = realAbs;
          arguments[2] = wrap(realAbs);
          parent.postMessage({ type: 'proxy:navigate', url: realAbs, title: document.title || '' }, '*');
        }
      } catch (e) {}
      return orig.apply(this, arguments);
    };
  }
  patchHistory('pushState');
  patchHistory('replaceState');

  // Clicks on links: ensure they go through the proxy (covers hrefs set weirdly)
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (skip(href)) return;
    var w = wrap(href);
    if (w !== href) _setAttribute.call(a, 'href', w);
    if (a.target && a.target !== '_self') _setAttribute.call(a, 'target', '_self');
  }, true);

  // Forms: rewrite action on submit, handle GET forms correctly (query merging)
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f || f.tagName !== 'FORM') return;
    var action = f.getAttribute('action');
    var real = action && !isProxied(action) ? abs(action) : (action ? unwrap(action) : BASE);
    var method = (f.getAttribute('method') || 'get').toLowerCase();
    if (method === 'get') {
      // Browser would replace the query string of /proxy, so build the URL ourselves
      e.preventDefault();
      var fd = new FormData(f);
      var u = new URL(real);
      u.search = '';
      var params = new URLSearchParams();
      fd.forEach(function (v, k) { if (typeof v === 'string') params.append(k, v); });
      if (e.submitter && e.submitter.name) params.append(e.submitter.name, e.submitter.value || '');
      u.search = params.toString();
      location.href = PREFIX + encodeURIComponent(u.href);
    } else {
      _setAttribute.call(f, 'action', PREFIX + encodeURIComponent(real));
    }
  }, true);

  // ---- Shadow location helper for scripts that read document.referrer etc. ----
  try {
    Object.defineProperty(document, 'referrer', { get: function () { return BASE; }, configurable: true });
  } catch (e) {}

  // Keyboard shortcuts bubble to parent (Ctrl+L / Ctrl+T)
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'l' || e.key === 't' || e.key === 'w')) {
      e.preventDefault();
      parent.postMessage({ type: 'proxy:key', key: e.key }, '*');
    }
  });
})();
