/* Browser UI controller */
(function () {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const PROXY = '/proxy?url=';
  const NEWTAB = 'about:newtab';

  const tabStrip = $('#tab-strip');
  const content = $('#content');
  const omnibox = $('#omnibox');
  const omniForm = $('#omnibox-form');
  const suggBox = $('#suggestions');
  const lockIcon = $('#lock-icon');
  const progress = $('#progress');
  const backBtn = $('#back-btn');
  const fwdBtn = $('#forward-btn');
  const reloadBtn = $('#reload-btn');
  const bookmarkBtn = $('#bookmark-btn');
  const menu = $('#menu');

  // ---------- Storage ----------
  const store = {
    get(k, d) { try { return JSON.parse(localStorage.getItem('wb:' + k)) ?? d; } catch { return d; } },
    set(k, v) { localStorage.setItem('wb:' + k, JSON.stringify(v)); },
  };
  let bookmarks = store.get('bookmarks', [
    { title: 'Wikipedia', url: 'https://en.wikipedia.org/' },
    { title: 'Bing', url: 'https://www.bing.com/' },
    { title: 'Hacker News', url: 'https://news.ycombinator.com/' },
    { title: 'BBC News', url: 'https://www.bbc.com/news' },
    { title: 'MDN', url: 'https://developer.mozilla.org/' },
    { title: 'Archive.org', url: 'https://archive.org/' },
  ]);
  let history = store.get('history', []); // [{url,title,time}]
  let searchEngine = store.get('engine', 'bing');

  const ENGINES = {
    bing: { name: 'Bing', url: 'https://www.bing.com/search?q=%s' },
    brave: { name: 'Brave', url: 'https://search.brave.com/search?q=%s' },
    duckduckgo: { name: 'DuckDuckGo', url: 'https://html.duckduckgo.com/html/?q=%s' },
    startpage: { name: 'Startpage', url: 'https://www.startpage.com/do/search?q=%s' },
    google: { name: 'Google', url: 'https://www.google.com/search?q=%s' },
  };

  // ---------- URL helpers ----------
  function normalize(input) {
    const q = input.trim();
    if (!q) return NEWTAB;
    if (q === NEWTAB || q === 'about:blank') return NEWTAB;
    if (/^https?:\/\//i.test(q)) return q;
    if (!/\s/.test(q) && /^[\w.-]+\.[a-z]{2,}(?::\d+)?(\/.*)?$/i.test(q)) return 'https://' + q;
    if (/^localhost(:\d+)?(\/.*)?$/i.test(q) || /^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/.test(q)) return 'http://' + q;
    return ENGINES[searchEngine].url.replace('%s', encodeURIComponent(q));
  }
  const proxied = (u) => PROXY + encodeURIComponent(u);
  function hostOf(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } }
  function favicon(u) {
    try { return 'https://icons.duckduckgo.com/ip3/' + new URL(u).hostname + '.ico'; } catch { return ''; }
  }

  // ---------- Tabs ----------
  let tabs = [];
  let activeId = null;
  let nextId = 1;

  function createTab(url = NEWTAB, activate = true) {
    const id = nextId++;
    const tab = { id, url, title: 'New Tab', history: [url], index: 0, loading: false, el: null, view: null, frame: null };

    // Tab button
    const el = document.createElement('div');
    el.className = 'tab';
    el.dataset.id = id;
    el.innerHTML = `<img class="fav" alt=""><span class="label"></span><button class="close" title="Close tab"><i class="fas fa-times"></i></button>`;
    el.addEventListener('click', (e) => { if (!e.target.closest('.close')) switchTab(id); });
    el.addEventListener('auxclick', (e) => { if (e.button === 1) closeTab(id); });
    el.querySelector('.close').addEventListener('click', (e) => { e.stopPropagation(); closeTab(id); });
    tabStrip.insertBefore(el, $('#new-tab-btn'));

    // View
    const view = document.createElement('section');
    view.className = 'view';
    view.dataset.id = id;
    content.appendChild(view);

    tab.el = el; tab.view = view;
    tabs.push(tab);
    renderTabView(tab);
    if (activate) switchTab(id);
    updateTabEl(tab);
    return tab;
  }

  function renderTabView(tab) {
    tab.view.innerHTML = '';
    tab.frame = null;
    if (tab.url === NEWTAB) {
      tab.view.appendChild(buildNewTabPage());
      tab.title = 'New Tab';
      tab.loading = false;
    } else {
      const f = document.createElement('iframe');
      f.setAttribute('sandbox', 'allow-scripts allow-forms allow-same-origin allow-popups allow-modals allow-downloads allow-pointer-lock');
      f.setAttribute('allow', 'fullscreen; autoplay; clipboard-write');
      f.referrerPolicy = 'no-referrer';
      f.src = proxied(tab.url);
      tab.loading = true;
      f.addEventListener('load', () => {
        tab.loading = false;
        // Try to read the real URL from the frame (same-origin via proxy)
        try {
          const loc = f.contentWindow.location;
          const p = new URL(loc.href).searchParams.get('url');
          if (p && p !== tab.url) {
            tab.url = p;
            tab.history[tab.index] = p;
          }
          const t = f.contentDocument && f.contentDocument.title;
          if (t) tab.title = t;
        } catch { /* cross-origin — ignore */ }
        if (!tab.title || tab.title === 'New Tab') tab.title = hostOf(tab.url);
        updateTabEl(tab);
        if (tab.id === activeId) updateChrome();
        addHistory(tab.url, tab.title);
      });
      tab.frame = f;
      tab.view.appendChild(f);
    }
    updateTabEl(tab);
  }

  function updateTabEl(tab) {
    const fav = tab.el.querySelector('.fav');
    tab.el.querySelector('.label').textContent = tab.title || hostOf(tab.url) || 'New Tab';
    tab.el.title = tab.url === NEWTAB ? 'New Tab' : tab.url;
    if (tab.loading) {
      fav.classList.add('spin'); fav.removeAttribute('src');
    } else {
      fav.classList.remove('spin');
      if (tab.url === NEWTAB) {
        fav.src = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#8ab4f8"><circle cx="12" cy="12" r="10"/></svg>');
      } else {
        fav.src = favicon(tab.url);
        fav.onerror = () => { fav.onerror = null; fav.src = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#9aa0a6"><circle cx="12" cy="12" r="10"/></svg>'); };
      }
    }
  }

  function switchTab(id) {
    activeId = id;
    tabs.forEach((t) => {
      t.el.classList.toggle('active', t.id === id);
      t.view.classList.toggle('active', t.id === id);
    });
    updateChrome();
    const t = current();
    if (t && t.url === NEWTAB) setTimeout(() => { const i = t.view.querySelector('input'); i && i.focus(); }, 0);
    t && t.el.scrollIntoView({ inline: 'nearest', block: 'nearest' });
  }

  function closeTab(id) {
    const i = tabs.findIndex((t) => t.id === id);
    if (i < 0) return;
    const [tab] = tabs.splice(i, 1);
    tab.el.remove(); tab.view.remove();
    if (tabs.length === 0) { createTab(); return; }
    if (activeId === id) switchTab(tabs[Math.min(i, tabs.length - 1)].id);
  }

  const current = () => tabs.find((t) => t.id === activeId);

  // ---------- Navigation ----------
  function navigate(input, tab = current()) {
    if (!tab) return;
    const url = normalize(input);
    tab.history = tab.history.slice(0, tab.index + 1);
    tab.history.push(url);
    tab.index = tab.history.length - 1;
    tab.url = url;
    tab.title = url === NEWTAB ? 'New Tab' : hostOf(url);
    renderTabView(tab);
    updateChrome();
    suggBox.classList.remove('open');
    if (url !== NEWTAB) omnibox.blur();
  }
  function goBack() { const t = current(); if (t && t.index > 0) { t.index--; t.url = t.history[t.index]; t.title = hostOf(t.url); renderTabView(t); updateChrome(); } }
  function goForward() { const t = current(); if (t && t.index < t.history.length - 1) { t.index++; t.url = t.history[t.index]; t.title = hostOf(t.url); renderTabView(t); updateChrome(); } }
  function reload() { const t = current(); if (!t) return; if (t.loading && t.frame) { t.frame.src = 'about:blank'; t.loading = false; updateChrome(); return; } renderTabView(t); updateChrome(); }

  function updateChrome() {
    const t = current();
    if (!t) return;
    if (document.activeElement !== omnibox) omnibox.value = t.url === NEWTAB ? '' : t.url;
    backBtn.disabled = t.index <= 0;
    fwdBtn.disabled = t.index >= t.history.length - 1;
    reloadBtn.innerHTML = t.loading ? '<i class="fas fa-times"></i>' : '<i class="fas fa-rotate-right"></i>';
    reloadBtn.title = t.loading ? 'Stop' : 'Reload';
    lockIcon.className = t.url.startsWith('https://') ? 'fas fa-lock secure' : (t.url === NEWTAB ? 'fas fa-magnifying-glass' : 'fas fa-triangle-exclamation');
    progress.className = t.loading ? 'loading' : 'done';
    const bm = bookmarks.some((b) => b.url === t.url);
    bookmarkBtn.classList.toggle('on', bm);
    bookmarkBtn.innerHTML = bm ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
    document.title = (t.title && t.title !== 'New Tab' ? t.title + ' — ' : '') + 'Cloud Browser';
  }

  // ---------- Messages from proxied frames ----------
  window.addEventListener('message', (e) => {
    const d = e.data;
    if (!d || typeof d !== 'object') return;
    const tab = tabs.find((t) => t.frame && t.frame.contentWindow === e.source);
    if (d.type === 'proxy:navigate' && tab) {
      if (d.url && d.url !== tab.url) {
        tab.url = d.url;
        tab.history[tab.index] = d.url;
      }
      if (d.title) tab.title = d.title;
      updateTabEl(tab);
      if (tab.id === activeId) updateChrome();
    } else if (d.type === 'proxy:open' && d.url) {
      createTab(d.url, true);
    } else if (d.type === 'proxy:key') {
      if (d.key === 'l') { omnibox.focus(); omnibox.select(); }
      if (d.key === 't') createTab();
      if (d.key === 'w' && tab) closeTab(tab.id);
    }
  });

  // ---------- History ----------
  function addHistory(url, title) {
    if (!url || url === NEWTAB) return;
    history = history.filter((h) => h.url !== url);
    history.unshift({ url, title: title || hostOf(url), time: Date.now() });
    history = history.slice(0, 300);
    store.set('history', history);
  }

  // ---------- Omnibox & suggestions ----------
  let suggItems = [];
  let suggSel = -1;
  let suggTimer = null;

  omniForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (suggSel >= 0 && suggItems[suggSel]) navigate(suggItems[suggSel].value);
    else navigate(omnibox.value);
  });
  omnibox.addEventListener('focus', () => omnibox.select());
  omnibox.addEventListener('input', () => {
    clearTimeout(suggTimer);
    suggTimer = setTimeout(() => showSuggestions(omnibox.value), 120);
  });
  omnibox.addEventListener('keydown', (e) => {
    if (!suggBox.classList.contains('open')) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); suggSel = Math.min(suggSel + 1, suggItems.length - 1); paintSel(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); suggSel = Math.max(suggSel - 1, -1); paintSel(); }
    else if (e.key === 'Escape') { suggBox.classList.remove('open'); omnibox.blur(); updateChrome(); }
  });
  omnibox.addEventListener('blur', () => setTimeout(() => { suggBox.classList.remove('open'); updateChrome(); }, 150));

  async function showSuggestions(q) {
    q = q.trim();
    suggItems = []; suggSel = -1;
    if (!q) { suggBox.classList.remove('open'); return; }
    const lower = q.toLowerCase();
    const isUrlish = !/\s/.test(q) && /[.:/]/.test(q);
    if (isUrlish) suggItems.push({ icon: 'fa-globe', text: normalize(q), value: q, meta: 'Go to site' });
    else suggItems.push({ icon: 'fa-magnifying-glass', text: q, value: q, meta: ENGINES[searchEngine].name + ' search' });
    history.filter((h) => h.url.toLowerCase().includes(lower) || (h.title || '').toLowerCase().includes(lower)).slice(0, 4)
      .forEach((h) => suggItems.push({ icon: 'fa-clock-rotate-left', text: h.title ? `${h.title} — ${h.url}` : h.url, value: h.url, meta: 'History' }));
    bookmarks.filter((b) => b.url.toLowerCase().includes(lower) || b.title.toLowerCase().includes(lower)).slice(0, 3)
      .forEach((b) => suggItems.push({ icon: 'fa-star', text: `${b.title} — ${b.url}`, value: b.url, meta: 'Bookmark' }));
    paintSugg();
    if (!isUrlish) {
      try {
        const r = await fetch('/api/suggest?q=' + encodeURIComponent(q));
        const list = await r.json();
        if (omnibox.value.trim() !== q) return;
        list.slice(0, 5).forEach((s) => { if (!suggItems.some((i) => i.value === s)) suggItems.push({ icon: 'fa-magnifying-glass', text: s, value: s, meta: '' }); });
        paintSugg();
      } catch { /* ignore */ }
    }
  }
  function paintSugg() {
    suggBox.innerHTML = suggItems.map((s, i) => `<div class="sugg${i === suggSel ? ' sel' : ''}" data-i="${i}"><i class="fas ${s.icon}"></i><span class="txt"></span><span class="meta"></span></div>`).join('');
    suggBox.querySelectorAll('.sugg').forEach((el, i) => {
      el.querySelector('.txt').textContent = suggItems[i].text;
      el.querySelector('.meta').textContent = suggItems[i].meta;
      el.addEventListener('mousedown', (e) => { e.preventDefault(); navigate(suggItems[i].value); });
    });
    suggBox.classList.toggle('open', suggItems.length > 0);
  }
  function paintSel() {
    suggBox.querySelectorAll('.sugg').forEach((el, i) => el.classList.toggle('sel', i === suggSel));
    if (suggSel >= 0) omnibox.value = suggItems[suggSel].value;
  }

  // ---------- New tab page ----------
  function buildNewTabPage() {
    const wrap = document.createElement('div');
    wrap.className = 'ntp';
    wrap.innerHTML = `
      <h1><i class="fas fa-cloud"></i>Cloud Browser</h1>
      <div class="sub">Browse the web from inside this page. Powered by Cloudflare edge.</div>
      <form class="ntp-search" id="ntp-search-form">
        <i class="fas fa-magnifying-glass"></i>
        <input type="text" id="ntp-search-input" placeholder="Search ${ENGINES[searchEngine].name} or type a URL" autocomplete="off" spellcheck="false">
      </form>
      <div class="shortcuts" id="shortcuts"></div>
      <div class="hint">Tip: <kbd>Ctrl</kbd>+<kbd>L</kbd> focuses the address bar · <kbd>Ctrl</kbd>+<kbd>T</kbd> new tab · <kbd>Ctrl</kbd>+<kbd>W</kbd> close tab.<br>Some sites (e.g. those requiring login or heavy JavaScript apps) may not work perfectly through the proxy.</div>`;
    wrap.querySelector('#ntp-search-form').addEventListener('submit', (e) => { e.preventDefault(); navigate(wrap.querySelector('#ntp-search-input').value); });
    const sc = wrap.querySelector('#shortcuts');
    bookmarks.forEach((b, i) => {
      const a = document.createElement('a');
      a.className = 'shortcut'; a.href = '#';
      a.innerHTML = `<div class="ico"><img alt="" loading="lazy"></div><span></span><button class="rm" title="Remove"><i class="fas fa-times"></i></button>`;
      a.querySelector('img').src = favicon(b.url);
      a.querySelector('img').onerror = function () { this.parentNode.innerHTML = '<i class="fas fa-globe"></i>'; };
      a.querySelector('span').textContent = b.title;
      a.addEventListener('click', (e) => { e.preventDefault(); if (e.target.closest('.rm')) { bookmarks.splice(i, 1); store.set('bookmarks', bookmarks); renderAllNewTabs(); } else navigate(b.url); });
      sc.appendChild(a);
    });
    const add = document.createElement('a');
    add.className = 'shortcut'; add.href = '#';
    add.innerHTML = `<div class="ico"><i class="fas fa-plus"></i></div><span>Add shortcut</span>`;
    add.addEventListener('click', (e) => {
      e.preventDefault();
      const url = prompt('Site URL:'); if (!url) return;
      const n = normalize(url); const title = prompt('Name:', hostOf(n)) || hostOf(n);
      bookmarks.push({ title, url: n }); store.set('bookmarks', bookmarks); renderAllNewTabs();
    });
    sc.appendChild(add);
    return wrap;
  }
  function renderAllNewTabs() { tabs.filter((t) => t.url === NEWTAB).forEach(renderTabView); }

  // ---------- Buttons ----------
  backBtn.addEventListener('click', goBack);
  fwdBtn.addEventListener('click', goForward);
  reloadBtn.addEventListener('click', reload);
  $('#home-btn').addEventListener('click', () => navigate(NEWTAB));
  $('#new-tab-btn').addEventListener('click', () => createTab());
  $('#go-btn').addEventListener('click', () => navigate(omnibox.value));
  bookmarkBtn.addEventListener('click', () => {
    const t = current(); if (!t || t.url === NEWTAB) return;
    const i = bookmarks.findIndex((b) => b.url === t.url);
    if (i >= 0) { bookmarks.splice(i, 1); toast('Bookmark removed'); }
    else { bookmarks.push({ title: t.title || hostOf(t.url), url: t.url }); toast('Bookmarked'); }
    store.set('bookmarks', bookmarks); updateChrome(); renderAllNewTabs();
  });

  // Menu
  $('#menu-btn').addEventListener('click', (e) => { e.stopPropagation(); menu.classList.toggle('open'); });
  document.addEventListener('click', () => menu.classList.remove('open'));
  menu.addEventListener('click', (e) => e.stopPropagation());
  $('#m-newtab').addEventListener('click', () => { createTab(); menu.classList.remove('open'); });
  $('#m-open').addEventListener('click', () => { const t = current(); if (t && t.url !== NEWTAB) window.open(t.url, '_blank', 'noopener'); menu.classList.remove('open'); });
  $('#m-copy').addEventListener('click', async () => { const t = current(); if (t && t.url !== NEWTAB) { try { await navigator.clipboard.writeText(t.url); toast('URL copied'); } catch { prompt('URL:', t.url); } } menu.classList.remove('open'); });
  $('#m-engine').addEventListener('click', () => {
    const keys = Object.keys(ENGINES);
    searchEngine = keys[(keys.indexOf(searchEngine) + 1) % keys.length];
    store.set('engine', searchEngine);
    $('#m-engine span').textContent = 'Search engine: ' + ENGINES[searchEngine].name;
    renderAllNewTabs(); toast('Search engine: ' + ENGINES[searchEngine].name);
  });
  $('#m-engine span').textContent = 'Search engine: ' + ENGINES[searchEngine].name;
  $('#m-clear').addEventListener('click', () => { history = []; store.set('history', []); toast('History cleared'); menu.classList.remove('open'); });
  $('#m-fullscreen').addEventListener('click', () => { document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen(); menu.classList.remove('open'); });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey || e.metaKey)) return;
    if (e.key === 'l') { e.preventDefault(); omnibox.focus(); omnibox.select(); }
    else if (e.key === 't') { e.preventDefault(); createTab(); }
    else if (e.key === 'w') { e.preventDefault(); const t = current(); t && closeTab(t.id); }
    else if (e.key === 'r') { e.preventDefault(); reload(); }
    else if (e.key === 'Tab') { e.preventDefault(); const i = tabs.findIndex((t) => t.id === activeId); switchTab(tabs[(i + (e.shiftKey ? -1 : 1) + tabs.length) % tabs.length].id); }
  });

  let toastTimer;
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 1800); }

  // ---------- Boot ----------
  const startUrl = new URLSearchParams(location.search).get('url');
  createTab(startUrl ? normalize(startUrl) : NEWTAB);
  if (startUrl) window.history.replaceState({}, '', '/');
})();
