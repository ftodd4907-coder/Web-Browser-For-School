/**
 * Proxy engine for the in-site browser.
 *
 * Fetches a remote URL on the edge, strips frame-blocking headers and
 * rewrites every URL inside HTML / CSS so the page keeps flowing through
 * the proxy when it is displayed inside the browser's <iframe>.
 */

export const PROXY_PREFIX = '/proxy?url='

export function toProxyUrl(absUrl: string): string {
  return PROXY_PREFIX + encodeURIComponent(absUrl)
}

/** Turn user input into a URL: accepts bare domains, full URLs, or search terms. */
export function normalizeInput(input: string): string {
  const q = input.trim()
  if (!q) return 'https://www.bing.com/'
  if (/^https?:\/\//i.test(q)) return q
  // Looks like a hostname (with optional path) and no spaces
  if (!/\s/.test(q) && /^[\w.-]+\.[a-z]{2,}(?::\d+)?(\/.*)?$/i.test(q)) return 'https://' + q
  if (/^localhost(:\d+)?(\/.*)?$/i.test(q) || /^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/.test(q)) return 'http://' + q
  return 'https://www.bing.com/search?q=' + encodeURIComponent(q)
}

const BLOCKED_HOSTS = new Set(['localhost', '127.0.0.1', '0.0.0.0', '::1', 'metadata.google.internal'])

export function validateTarget(raw: string): URL | null {
  let u: URL
  try {
    u = new URL(raw)
  } catch {
    return null
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return null
  const host = u.hostname.toLowerCase()
  if (BLOCKED_HOSTS.has(host)) return null
  // Block RFC1918 / link-local ranges
  if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|fc|fd|fe80)/i.test(host)) return null
  return u
}

/** HTMLRewriter hands us raw attribute text, so entities must be decoded first. */
function decodeEntities(s: string): string {
  if (!s.includes('&')) return s
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_m, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_m, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&(amp|lt|gt|quot|apos|nbsp);/gi, (_m, n) => ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' })[n.toLowerCase()]!)
}

/** Resolve a (possibly relative) URL against a base and wrap it in the proxy. */
export function rewriteUrl(value: string, base: string): string {
  const v = decodeEntities(value).trim()
  if (!v) return value
  if (/^(data:|blob:|javascript:|mailto:|tel:|about:|#)/i.test(v)) return value
  if (v.includes('/proxy?url=')) return value
  try {
    const abs = new URL(v, base).href
    return toProxyUrl(abs)
  } catch {
    return value
  }
}

/** Rewrite a srcset attribute value: "url 1x, url2 2x". */
function rewriteSrcset(value: string, base: string): string {
  return value
    .split(',')
    .map((part) => {
      const trimmed = part.trim()
      if (!trimmed) return trimmed
      const [url, ...rest] = trimmed.split(/\s+/)
      return [rewriteUrl(url, base), ...rest].join(' ')
    })
    .join(', ')
}

/** Rewrite url(...) and @import inside CSS text. */
export function rewriteCss(css: string, base: string): string {
  let out = css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (_m, quote, url) => {
    return `url(${quote}${rewriteUrl(url, base)}${quote})`
  })
  out = out.replace(/@import\s+(['"])([^'"]+)\1/gi, (_m, quote, url) => {
    return `@import ${quote}${rewriteUrl(url, base)}${quote}`
  })
  return out
}

// Headers that must not be forwarded from the origin response
const STRIP_RESPONSE_HEADERS = [
  'content-security-policy',
  'content-security-policy-report-only',
  'x-frame-options',
  'cross-origin-opener-policy',
  'cross-origin-embedder-policy',
  'cross-origin-resource-policy',
  'strict-transport-security',
  'content-length',
  'content-encoding',
  'transfer-encoding',
  'set-cookie',
  'report-to',
  'nel',
  'permissions-policy',
  'x-xss-protection',
  'link', // may contain preload links pointing at the origin
]

// Request headers we forward from the browser
const FORWARD_REQUEST_HEADERS = ['accept', 'accept-language', 'range', 'content-type', 'cache-control', 'pragma']

const URL_ATTRS: Array<[string, string]> = [
  ['a', 'href'],
  ['area', 'href'],
  ['link', 'href'],
  ['img', 'src'],
  ['img', 'srcset'],
  ['source', 'src'],
  ['source', 'srcset'],
  ['script', 'src'],
  ['iframe', 'src'],
  ['frame', 'src'],
  ['embed', 'src'],
  ['object', 'data'],
  ['video', 'src'],
  ['video', 'poster'],
  ['audio', 'src'],
  ['track', 'src'],
  ['input', 'src'],
  ['form', 'action'],
  ['button', 'formaction'],
  ['input', 'formaction'],
]

class AttrRewriter {
  constructor(private attr: string, private base: string) {}
  element(el: Element) {
    const v = el.getAttribute(this.attr)
    if (v === null) return
    if (this.attr === 'srcset') el.setAttribute(this.attr, rewriteSrcset(v, this.base))
    else el.setAttribute(this.attr, rewriteUrl(v, this.base))
  }
}

/** SVG <use>/<image> may reference external files via href / xlink:href. */
class SvgRefRewriter {
  constructor(private base: string) {}
  element(el: Element) {
    for (const attr of ['href', 'xlink:href']) {
      const v = el.getAttribute(attr)
      if (v && !v.startsWith('#')) el.setAttribute(attr, rewriteUrl(v, this.base))
    }
  }
}

class IntegrityStripper {
  element(el: Element) {
    el.removeAttribute('integrity')
    el.removeAttribute('nonce')
    // crossorigin attributes make fetches fail for proxied content
    el.removeAttribute('crossorigin')
  }
}

class MetaHandler {
  constructor(private base: string) {}
  element(el: Element) {
    const httpEquiv = (el.getAttribute('http-equiv') || '').toLowerCase()
    if (httpEquiv === 'content-security-policy' || httpEquiv === 'x-frame-options') {
      el.remove()
      return
    }
    if (httpEquiv === 'refresh') {
      const content = el.getAttribute('content') || ''
      const m = content.match(/^\s*([\d.]+)\s*;\s*url\s*=\s*['"]?([^'"]+)['"]?/i)
      if (m) el.setAttribute('content', `${m[1]}; url=${rewriteUrl(m[2], this.base)}`)
    }
  }
}

class BaseHandler {
  element(el: Element) {
    // Remove <base> tags: we have already resolved everything to absolute URLs
    el.remove()
  }
}

class StyleAttrHandler {
  constructor(private base: string) {}
  element(el: Element) {
    const s = el.getAttribute('style')
    if (s && /url\(/i.test(s)) el.setAttribute('style', rewriteCss(s, this.base))
  }
}

class StyleTagHandler {
  private buf = ''
  constructor(private base: string) {}
  text(t: Text) {
    this.buf += t.text
    if (t.lastInTextNode) {
      t.replace(rewriteCss(this.buf, this.base), { html: true })
      this.buf = ''
    } else {
      t.remove()
    }
  }
}

class HeadInjector {
  constructor(private script: string) {}
  element(el: Element) {
    el.prepend(this.script, { html: true })
  }
}

class TargetRemover {
  element(el: Element) {
    const t = el.getAttribute('target')
    if (t && t !== '_self') el.setAttribute('target', '_self')
    // Prevent "ping" beacons
    el.removeAttribute('ping')
  }
}

export interface ProxyOptions {
  /** URL of the client-side shim script to inject into HTML pages. */
  shimSrc: string
}

export async function proxyRequest(req: Request, opts: ProxyOptions): Promise<Response> {
  const reqUrl = new URL(req.url)
  const raw = reqUrl.searchParams.get('url') || ''
  const target = validateTarget(raw)
  if (!target) {
    return new Response(errorPage('Invalid or blocked URL', raw), {
      status: 400,
      headers: { 'content-type': 'text/html; charset=utf-8' },
    })
  }

  // Build outbound request
  const headers = new Headers()
  for (const h of FORWARD_REQUEST_HEADERS) {
    const v = req.headers.get(h)
    if (v) headers.set(h, v)
  }
  // An honest, identifying UA works better than a spoofed one: several sites
  // (e.g. Wikipedia) block "browser" UAs coming from datacenter IPs.
  headers.set('user-agent', 'Mozilla/5.0 (compatible; CloudBrowser/1.0; +https://workers.cloudflare.com) AppleWebKit/537.36')
  headers.set('referer', target.origin + '/')
  headers.set('origin', target.origin)
  headers.set('accept-encoding', 'identity')

  const init: RequestInit = {
    method: req.method,
    headers,
    redirect: 'manual',
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    init.body = req.body
    // @ts-ignore - needed for streaming bodies on some runtimes
    init.duplex = 'half'
  }

  let upstream: Response
  try {
    upstream = await fetch(target.href, init)
  } catch (e: any) {
    return new Response(errorPage('Could not reach site', target.href, String(e?.message || e)), {
      status: 502,
      headers: { 'content-type': 'text/html; charset=utf-8' },
    })
  }

  // Handle redirects by redirecting through the proxy
  if (upstream.status >= 300 && upstream.status < 400) {
    const loc = upstream.headers.get('location')
    if (loc) {
      const abs = new URL(loc, target.href).href
      return Response.redirect(new URL(toProxyUrl(abs), reqUrl.origin).href, 302)
    }
  }

  const outHeaders = new Headers()
  upstream.headers.forEach((v, k) => {
    if (!STRIP_RESPONSE_HEADERS.includes(k.toLowerCase())) outHeaders.set(k, v)
  })
  outHeaders.set('access-control-allow-origin', '*')
  outHeaders.set('x-proxied-url', target.href)
  outHeaders.set('x-proxied-status', String(upstream.status))
  // Expose the final URL so the UI can update the address bar
  outHeaders.set('access-control-expose-headers', 'x-proxied-url, x-proxied-status')

  const ctype = (upstream.headers.get('content-type') || '').toLowerCase()

  // HTML → rewrite with HTMLRewriter
  if (ctype.includes('text/html') || ctype.includes('application/xhtml')) {
    const base = target.href
    const shim = `<script>window.__PROXY_BASE__=${JSON.stringify(base)};</script><script src="${opts.shimSrc}"></script>`

    let rw = new HTMLRewriter()
      .on('base', new BaseHandler())
      .on('meta', new MetaHandler(base))
      .on('head', new HeadInjector(shim))
      .on('a, area, form', new TargetRemover())
      .on('script, link', new IntegrityStripper())
      .on('style', new StyleTagHandler(base))
      .on('use, image', new SvgRefRewriter(base))
      .on('[style]', new StyleAttrHandler(base))

    for (const [tag, attr] of URL_ATTRS) {
      rw = rw.on(`${tag}[${attr}]`, new AttrRewriter(attr, base))
    }

    // Pass through as a 200 so iframes render error pages too
    const res = new Response(upstream.body, { status: upstream.status, headers: outHeaders })
    return rw.transform(res)
  }

  // CSS → rewrite url() references
  if (ctype.includes('text/css')) {
    const css = await upstream.text()
    return new Response(rewriteCss(css, target.href), { status: upstream.status, headers: outHeaders })
  }

  // Everything else: stream straight through
  return new Response(upstream.body, { status: upstream.status, headers: outHeaders })
}

export function errorPage(title: string, url: string, detail = ''): string {
  const esc = (s: string) => s.replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]!)
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>body{font-family:system-ui,sans-serif;background:#1f1f1f;color:#e3e3e3;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{max-width:520px;padding:32px;text-align:center}h1{font-size:22px;margin:0 0 12px}p{color:#9aa0a6;word-break:break-all}.d{font-size:12px;color:#777;margin-top:16px}</style></head>
<body><div class="box"><div style="font-size:48px;margin-bottom:12px">&#9888;</div><h1>${esc(title)}</h1><p>${esc(url)}</p>${detail ? `<div class="d">${esc(detail)}</div>` : ''}</div></body></html>`
}
