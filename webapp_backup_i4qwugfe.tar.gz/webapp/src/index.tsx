import { Hono } from 'hono'
import { proxyRequest, toProxyUrl, validateTarget } from './proxy'

const app = new Hono()

// ---------- The browser UI ----------
app.get('/', (c) => {
  return c.html(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cloud Browser</title>
  <meta name="description" content="A web browser that runs inside your browser, powered by Cloudflare's edge.">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%238ab4f8'%3E%3Cpath d='M19.35 10.04A7.49 7.49 0 0 0 12 4C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 0 0 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z'/%3E%3C/svg%3E">
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
  <link href="/static/style.css" rel="stylesheet">
</head>
<body>
  <div id="browser">
    <header id="tab-strip">
      <button id="new-tab-btn" title="New tab (Ctrl+T)"><i class="fas fa-plus"></i></button>
    </header>

    <nav id="toolbar">
      <button class="nav-btn" id="back-btn" title="Back"><i class="fas fa-arrow-left"></i></button>
      <button class="nav-btn" id="forward-btn" title="Forward"><i class="fas fa-arrow-right"></i></button>
      <button class="nav-btn" id="reload-btn" title="Reload"><i class="fas fa-rotate-right"></i></button>
      <button class="nav-btn" id="home-btn" title="Home"><i class="fas fa-house"></i></button>

      <div id="omnibox-wrap">
        <form id="omnibox-form" autocomplete="off">
          <i id="lock-icon" class="fas fa-magnifying-glass"></i>
          <input id="omnibox" type="text" placeholder="Search or enter a URL" spellcheck="false" autocapitalize="off" autocorrect="off">
          <button type="button" id="bookmark-btn" title="Bookmark this page"><i class="far fa-star"></i></button>
          <button type="submit" id="go-btn" title="Go"><i class="fas fa-arrow-right"></i></button>
        </form>
        <div id="suggestions" role="listbox"></div>
      </div>

      <button class="nav-btn" id="menu-btn" title="Menu"><i class="fas fa-ellipsis-vertical"></i></button>
    </nav>

    <div id="progress"><div class="bar"></div></div>

    <main id="content"></main>
  </div>

  <div id="menu">
    <button id="m-newtab"><i class="fas fa-plus"></i> New tab</button>
    <button id="m-open"><i class="fas fa-arrow-up-right-from-square"></i> Open in real browser</button>
    <button id="m-copy"><i class="fas fa-copy"></i> Copy URL</button>
    <hr>
    <button id="m-engine"><i class="fas fa-magnifying-glass"></i> <span>Search engine</span></button>
    <button id="m-clear"><i class="fas fa-broom"></i> Clear history</button>
    <button id="m-fullscreen"><i class="fas fa-expand"></i> Toggle fullscreen</button>
  </div>

  <div id="toast"></div>

  <script src="/static/app.js"></script>
</body>
</html>`)
})

// ---------- The proxy ----------
app.all('/proxy', (c) => {
  return proxyRequest(c.req.raw, { shimSrc: '/static/shim.js' })
})

// ---------- Search suggestions (DuckDuckGo autocomplete) ----------
app.get('/api/suggest', async (c) => {
  const q = c.req.query('q') || ''
  if (!q.trim()) return c.json([])
  try {
    const r = await fetch('https://duckduckgo.com/ac/?q=' + encodeURIComponent(q) + '&type=list', {
      headers: { 'user-agent': 'Mozilla/5.0' },
    })
    const data: any = await r.json()
    // format: ["query", ["s1","s2",...]]
    const list = Array.isArray(data) && Array.isArray(data[1]) ? data[1] : []
    return c.json(list.slice(0, 8), 200, { 'cache-control': 'public, max-age=3600' })
  } catch {
    return c.json([])
  }
})

// Health check
app.get('/api/health', (c) => c.json({ ok: true, time: new Date().toISOString() }))

// ---------- Fallback: requests that escaped the proxy ----------
// If a proxied page requests "/foo/bar.js" without going through the rewriter,
// the browser will ask us for it. Use the Referer header to figure out which
// site it belongs to and redirect it through the proxy.
app.all('*', (c) => {
  const referer = c.req.header('referer')
  if (referer) {
    try {
      const ref = new URL(referer)
      const target = ref.searchParams.get('url')
      if (ref.pathname === '/proxy' && target && validateTarget(target)) {
        const reqUrl = new URL(c.req.url)
        const abs = new URL(reqUrl.pathname + reqUrl.search, target).href
        return c.redirect(toProxyUrl(abs), 307)
      }
    } catch {
      /* ignore */
    }
  }
  return c.notFound()
})

export default app
